import java.util.Random;

/*
 * Adam Shay
 * CIT360
 * 9/9/2019 
 * 
 */
public class ComparingSorts {
	
	private final static int ARRAY_ONE = 100;
	private final static int ARRAY_TWO = 1000;
	private final static int MAX_VALUE = 1000;
	private final static int ITERATIONS = 10000;
	
	public static void main(String[]args) {

		double[] sortTimes;
		String[] sortTypes = {"Selection", "Insertion", "Bubble", "Quick", "Merge"};
		
		//Case 1
		System.out.println("Case 1: ");
		sortTimes = test(ARRAY_ONE, ITERATIONS);
		output(ARRAY_ONE, MAX_VALUE, ITERATIONS, sortTimes, sortTypes);
		//Case 2
		System.out.println("Case 2: ");
		sortTimes = test(ARRAY_TWO, ITERATIONS);
		output(ARRAY_TWO, MAX_VALUE, ITERATIONS, sortTimes, sortTypes);
	}
	
	//Testing - Returns Array of Average Times
	public static double[] test(int arraySize, int iterations) {
		
		long startTime;
		int[] array = new int[arraySize];
		double[] sortTimes = {0,0,0,0,0};

		for(int i = 0; i < iterations; i++) {
			if((i % 1000) == 0)
				System.out.print("*");
		randomFill(array);//Filling array with new random numbers each iteration
		
		startTime = System.nanoTime();
		selectionSort(copyArray(array));
		sortTimes[0] += System.nanoTime() - startTime;
		startTime = System.nanoTime();
		insertionSort(copyArray(array));
		sortTimes[1] += System.nanoTime() - startTime;
		startTime = System.nanoTime();
		bubbleSort(copyArray(array));
		sortTimes[2] += System.nanoTime() - startTime;
		startTime = System.nanoTime();
		quickSort(copyArray(array));
		sortTimes[3] += System.nanoTime() - startTime;
		startTime = System.nanoTime();
		mergeSort(copyArray(array));
		sortTimes[4] += System.nanoTime() - startTime;
		}
		for(int i = 0; i < 5; i++) { //Getting the Average
			sortTimes[i] = sortTimes[i]/iterations;
		}
		return sortTimes; //Return Array of Average Times
	}

	//Output
	public static void output(int arraysize, int maxvalue, int iterations, double[] sortTimes, String[] sortType){
		
		System.out.printf("%-20s%-20s%n", "\nArray Size: ", arraysize);
		System.out.printf("%-20s%-20s%n", "Max Value: ", maxvalue);
		System.out.printf("%-20s%-20s%n", "Iterations: ", iterations);
		System.out.println("Average Run Time(in Nano Seconds):");
		//Calculating Bar 
		double max = 0;
		double min = 999999;
		String[] bar = new String[5];
		for(double i:sortTimes) { //Set max for calculation
			 if (i > max)
				 max = i;
		}
		
		int j = 0;
		for(double i:sortTimes) { 
			bar[j] = " ";
			for(double k = 0; k<i/max; k= k + .07)
			 bar[j] += "*";
			j++;
		}
		//Average Run Times
		for(int i = 0; i<5; i++) {
			System.out.printf("%20s%-20s%s%n", sortType[i] + " Sort:", bar[i], sortTimes[i]);
		}
		System.out.println("\n");
	}
	//Fill Array with Random Numbers
	public static void randomFill(int[] A) {
		for(int i = 0; i < A.length; i++) {
			Random rand = new Random();
			A[i] = rand.nextInt(MAX_VALUE);
		}
	}
	//Add all elements of an Array
	public static int sumArray(int[] array) {
		int sum = 0;
		for(int i:array) {
			sum += i;
		}
		return sum;
	}
	//Copy Array
	public static int[] copyArray(int[] array) {
		int[] copiedArray = new int[array.length];
		for(int i = 0; i < copiedArray.length; i++) {
			copiedArray[i] = array[i];
		}
		return copiedArray;	
	}
	
	public static String toString(int[] A) {
		String str = "[";
		
		for(int i = 0; i < A.length; i++)
			str += A[i] + ", ";
		
		str += "]";
		return str;
		
	}
	
	//Sorts
	public static void selectionSort(int[] A) {

		int maxValue;
		int pos;
		int temp;

		for (int i = 0; i < A.length - 1; i++) {
			pos = i;
			maxValue = A[i];
			for (int j = i; j < A.length; j++)
				if (A[j] > maxValue) {
					maxValue = A[j];
					pos = j;
				}
			temp = A[pos];
			A[pos] = A[i];
			A[i] = temp;

		}
	}
	public static void insertionSort(int[] A) { 
		int i, key, j;
		for (i = 1; i < A.length; i++) {
			key = A[i];
			j = i - 1;
			
			while (j >= 0 && A[j] > key) {
				A[j + 1] = A[j];
				j = j - 1;
			}
			A[j + 1] = key;
		}
	}
	public static void bubbleSort(int[] A) {
		int temp;
		boolean swapped = true;
		int count = 0;  

		while (swapped) { 
			swapped = false;
			for (int j = 0; j < A.length - 1 - count; j++) {
				if (A[j] > A[j + 1]) {
					swapped = true;
					temp = A[j];
					A[j] = A[j + 1];
					A[j + 1] = temp;
				}
			}
			count++;
		}
	}
	private static void mergeSort(int[] A) {
		int[] helper = new int[A.length];

		mergeSortHelper(A, helper, 0, A.length - 1);
	}

	private static void mergeSortHelper(int[] A, int[] helper, int low, int high) { 
		
		if (low < high) {

			int middle = low + (high - low) / 2;

			mergeSortHelper(A, helper, low, middle);

			mergeSortHelper(A, helper, middle + 1, high);

			merge(A, helper, low, middle, high);
		}
	}

	private static void merge(int[] A, int[] helper, int low, int middle, int high) {

		for (int i = low; i <= high; i++) {
			helper[i] = A[i];
		}
		int i = low;
		int j = middle + 1;
		int k = low;

		while (i <= middle && j <= high) {
			if (helper[i] <= helper[j]) {
				A[k] = helper[i];
				i++;
			} else {
				A[k] = helper[j];
				j++;
			}
			k++;
		}

		while (i <= middle) {
			A[k] = helper[i];
			k++;
			i++;
		}
	}
	public static void quickSort(int[] A) {
		quickSortHelper(A, 0, A.length - 1);
	}

	private static void quickSortHelper(int[] A, int lowerIndex, int higherIndex) {

		int i = lowerIndex; 
		int j = higherIndex; 
		int temp;

		int pivot = A[lowerIndex + (higherIndex - lowerIndex) / 2]; 
		while (i <= j) {
			
			while (A[i] < pivot) { 
				i++;
			}
			while (A[j] > pivot) { 
				j--;
			}
			if (i <= j) {
				temp = A[i];
				A[i] = A[j];
				A[j] = temp;
				i++;
				j--;
			}
		}
		if (lowerIndex < j)
			quickSortHelper(A, lowerIndex, j);
		if (i < higherIndex)
			quickSortHelper(A, i, higherIndex);
	}
}
	
	


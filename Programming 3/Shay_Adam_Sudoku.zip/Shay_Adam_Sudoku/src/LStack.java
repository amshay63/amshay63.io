
public class LStack<T>implements Stack<T>{
	
	private int size;
	private StackNode<T> top;
	
	
	
	
	public LStack(){
		top = null;
		size = 0;
	}
	
	/**
	 * O(1)
	 */
	@Override
	public T pop() {
		if(!isEmpty()) { 			//Assuming stack is not empty
			T data = top.getData(); //save data to return
			top = top.getNext(); 	//set top to the next element
			size--; 				//reduce the size by 1 and return
			return data;
		}
			
		return null;
	}
	/**
	 * O(1)
	 */
	@Override
	public void push(T e) {
		top = new StackNode(e, top); //create new node with e data, and set it to the top
		size++;
	}

	/**
	 * O(1)
	 */
	@Override
	public T peek() {
		if(!isEmpty()) { //If stack is not empty,
			StackNode<T> dataCopy = new StackNode(top.getData()); //Create a "deep copy" of the node for data security
			return dataCopy.getData(); //Return the copy of data
		}
		return null;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	
	private class StackNode<S> {

		private S data;
		private StackNode<S> next;
		
		
		public StackNode(S data, StackNode<S> next) {
			super();
			this.data = data;
			this.next = next;
		}
		
		public StackNode(S data) {
			super();
			this.data = data;
			this.next = null;
		}
		
		
		public StackNode() {
			super();
			this.data = null;
			this.next = null;
		}	
		
		public S getData() {
			return data;
		}

		public void setData(S data) {
			this.data = data;
		}

		public StackNode<S> getNext() {
			return next;
		}

		public void setNext(StackNode<S> next) {
			this.next = next;
		}

		@Override
		public String toString() {
			return data.toString();
		}
   
		
		
		
}
	
	
}

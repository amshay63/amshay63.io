import java.io.File;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

/**
 * Adam Shay 9/23/2019
 *
 */
public class Sudoku {

	private static final int rows = 4;
	private static final int cols = 4;

	public static void main(String[] args) {

		// Read XML File to 2D Array
		int[][] puzzle = ReadXMLFile();

		// Initialize Stack
		LStack<int[][]> stack = new LStack<int[][]>();

		// Read XML File to 2D Array
		int[][] temp;
		int[][] triedNums = new int[rows][cols];
		
		// Initialize Possibilities List
		ArrayList<Integer> numbers = new ArrayList<Integer>();

		// Push 2D Array to Stack
		stack.push(puzzle);

		boolean done = false;
		while (!stack.isEmpty() && !done) {
			// check to see if puzzle is complete
			if (checkGrid(stack.peek())) {
				done = true;
			}

			// If puzzle is done, print out completed puzzle
			if (done) {
				printGrid(stack.peek());
				System.out.println("Done");

			} else {
				// Else Pop stack
				temp = stack.pop();
				for (int i = 0; i < rows; i++) {
					for (int j = 0; j < cols; j++) {
						// find an empty slot and figure out all possible number inputs
						if (temp[i][j] == 0) {
							// Check Rows and Columns for Possibilities
							numbers = findPossibleNums(temp, i, j);
							//While numbers isn't empty, try every possibility
							if(!numbers.isEmpty()) {
								if(numbers.get(0) == triedNums[i][j]){
									numbers.remove(0);
								}
								temp[i][j] = numbers.get(0);
								//Add number to triedNums in case its the wrong number
								triedNums[i][j] = temp[i][j];
								stack.push(temp);
							}
							//If there is an issue, restart at the first number in the row and recheck
							else { 
								stack.pop();
								if(j>0) {
									j = 0;
									
								}
								else {
									i--;
									j = 0;
								}
								temp[i][j] = 0;
							}
						}
					}
				}

			}
		}
	}

	public static ArrayList<Integer> findPossibleNums(int[][] puzzle, int row, int col) {
		// Fill List with possible numbers
		ArrayList<Integer> possibleNums = new ArrayList<Integer>();
		for (int i = 1; i <= cols; i++) {
			possibleNums.add(i);
		}
			// Check Cols and Rows for possiblities
			for (int i = 0; i < rows; i++) {
				if (puzzle[row][i] != 0 && possibleNums.contains(puzzle[row][i])) {
					possibleNums.remove(possibleNums.indexOf(puzzle[row][i]));
				}
			}
			for (int i = 0; i < cols; i++) {
				if (puzzle[i][col] != 0 && possibleNums.contains(puzzle[i][col])) {
					possibleNums.remove(possibleNums.indexOf(puzzle[i][col]));
				}
			}
		return possibleNums;
	}

	public static int[][] ReadXMLFile() {

		int[][] puzzle = new int[rows][cols];
		int index, value, col, row;
		int nulls = 0;
		try {
			File fXmlFile = new File("Sudoku.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("sudoku");

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					for (int i = 0; i < 16; i++) {
						try {
							index = Integer.parseInt(eElement.getElementsByTagName("index").item(i).getTextContent());
							value = Integer.parseInt(eElement.getElementsByTagName("value").item(i).getTextContent());
							col = index % 4;
							row = index / 4;
							puzzle[row][col] = value;
						} catch (Exception e) {
							nulls += 1;
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return puzzle;
	}

	// Use row and col to check grid
	public static boolean checkGrid(int[][] puzzle) {
		// if (checkCols(puzzle) && checkRows(puzzle))
		if (!checkCols(puzzle)) {
			return false;
		}
		if (!checkRows(puzzle)) {
			return false;
		}
		return true;
	}

	// Check if all rows add up to 10 and if each square is between 0 and 5
	public static boolean checkRows(int[][] puzzle) {
		int[] count = new int[rows];

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if ((puzzle[i][j] > 0) && (puzzle[i][j] < 5))
					count[i] += puzzle[i][j];
			}
			if (count[i] != 10) {
				return false;
			}
		}
		return true;
	}

	// Check if all columns add up to 10 and if each square is between 0 and 5
	public static boolean checkCols(int[][] puzzle) {
		int[] count = new int[cols];

		for (int j = 0; j < rows; j++) {
			for (int i = 0; i < cols; i++) {
				if ((puzzle[i][j] > 0) && (puzzle[i][j] < 5))
					count[j] += puzzle[i][j];
			}
			if (count[j] != 10) {
				return false;
			}
		}
		return true;
	}

	public static void printGrid(int[][] grid) {
		System.out.println("---------------------------");
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {
				System.out.print(" | " + grid[i][j] + " | ");
			}
			System.out.println("\n---------------------------");
		}
	}
}

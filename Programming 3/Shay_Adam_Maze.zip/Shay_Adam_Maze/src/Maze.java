import java.awt.Point;
import java.util.Random;

/**
 * Adam Shay 10/31/2019
 * 
 * This program will generate a random maze
 * Then it will find the shortest path between two random points
 * If there is no path, "No Path Found" will be printed to the console
 * 
 */

public class Maze {

	// Generate Random Maze Size between 20-100
	static Random n = new Random();
	private static final int mazeSize = n.nextInt(80) + 20;

	public static void main(String[] args) {

		// Initialize Queue and Loop ending Variable
		LQueue<Point> queue = new LQueue<Point>();
		boolean done = false;

		// Initialize Start and End Randomly
		Point startPoint = randomPoint();
		Point endPoint = randomPoint();

		// Make Sure Start and End Points are Different
		while (startPoint.equals(endPoint)) {
			startPoint = randomPoint();
			endPoint = randomPoint();
		}

		// Make Maze, Distance, and Visited Arrays
		char[][] maze = new char[mazeSize][mazeSize];
		int[][] distance = new int[mazeSize][mazeSize];
		boolean[][] visited = new boolean[mazeSize][mazeSize];

		for (int r = 0; r < maze.length; r++) {
			for (int c = 0; c < maze[r].length; c++) {

				// Fill Distance and Visited Arrays
				distance[r][c] = Integer.MAX_VALUE;
				visited[r][c] = false;

				// Randomly Fill Grid
				if (Math.random() < .3) {
					maze[r][c] = 'x';
				} else {
					maze[r][c] = '-';
				}

				// Borders
				if ((r == 0 || r == maze.length - 1) || (c == 0 || c == maze[r].length - 1)) {
					maze[r][c] = 'x';
				}

				// Start Point, Distance Set to 0
				if (r == startPoint.y && c == startPoint.x) {
					maze[r][c] = 'S';
					distance[r][c] = 0;
				}

				// End Point
				if (r == endPoint.y && c == endPoint.x) {
					maze[r][c] = 'F';
				}

			}
		}

		// Queue Start Point
		queue.enqueue(startPoint);

		// As soon as point placed in queue, mark as visited
		visited[startPoint.y][startPoint.x] = true;

		while (!queue.isEmpty() && !done) {
			// Check if done (if point is finish point)
			if (queue.peek().equals(endPoint)) {
				done = true;
				// Backtrack to find the least distance
				Point back = (Point) endPoint.clone();
				while (distance[back.y][back.x] != 0) {
					if (distance[back.y - 1][back.x] == distance[back.y][back.x] - 1) {
						back.move(back.x, back.y - 1);
						maze[back.y][back.x] = 'o';
						continue;
					}

					if (distance[back.y][back.x + 1] == distance[back.y][back.x] - 1) {
						back.move(back.x + 1, back.y);
						maze[back.y][back.x] = 'o';
						continue;
					}

					if (distance[back.y + 1][back.x] == distance[back.y][back.x] - 1) {
						back.move(back.x, back.y + 1);
						maze[back.y][back.x] = 'o';
						continue;
					}

					if (distance[back.y][back.x - 1] == distance[back.y][back.x] - 1) {
						back.move(back.x - 1, back.y);
						maze[back.y][back.x] = 'o';
						continue;
					}
				}
				// Print Results
				maze[endPoint.y][endPoint.x] = 'F';
				maze[startPoint.y][startPoint.x] = 'S';
				printMaze(maze);
				System.out.println("Maze Size: " + mazeSize + "x" + mazeSize);
				System.out.println("Distance From Start-Finish: " + distance[endPoint.y][endPoint.x]);

			} else { // if not done

				// Dequeue into point variable
				Point point = queue.dequeue();

				// Set Distance to point coordinates
				int dist = distance[point.y][point.x];

				// create clone
				Point clone = (Point) point.clone();

				// North
				clone.move((clone.x), (clone.y - 1));
				Point nPoint = (Point) clone.clone();
				clone = (Point) point.clone();

				// East
				clone.move(clone.x + 1, clone.y);
				Point ePoint = (Point) clone.clone();
				clone = (Point) point.clone();

				// South
				clone.move(clone.x, clone.y + 1);
				Point sPoint = (Point) clone.clone();
				clone = (Point) point.clone();

				// West
				clone.move(clone.x - 1, clone.y);
				Point wPoint = (Point) clone.clone();
				clone = (Point) point.clone();

				// if neighbor is unvisited,
				// mark them visited, update distance array, put them on queue

				// North
				if (maze[nPoint.y][nPoint.x] != 'x' && visited[nPoint.y][nPoint.x] == false) {
					queue.enqueue(nPoint); // Enqueue point
					distance[nPoint.y][nPoint.x] = dist + 1;
					visited[nPoint.y][nPoint.x] = true;
				}
				// East
				if (maze[ePoint.y][ePoint.x] != 'x' && visited[ePoint.y][ePoint.x] == false) {
					queue.enqueue(ePoint);
					distance[ePoint.y][ePoint.x] = dist + 1;
					visited[ePoint.y][ePoint.x] = true;
				}
				// South
				if (maze[sPoint.y][sPoint.x] != 'x' && visited[sPoint.y][sPoint.x] == false) {
					queue.enqueue(sPoint);
					distance[sPoint.y][sPoint.x] = dist + 1;
					visited[sPoint.y][sPoint.x] = true;
				}
				// West
				if (maze[wPoint.y][wPoint.x] != 'x' && visited[wPoint.y][wPoint.x] == false) {
					queue.enqueue(wPoint);
					distance[wPoint.y][wPoint.x] = dist + 1;
					visited[wPoint.y][wPoint.x] = true;
				}

			}
		}
		if (!done)
			System.out.println("No Path Found");
	}

	public static Point randomPoint() {
		Random r = new Random();
		Point point = new Point();
		int x = r.nextInt(mazeSize - 2) + 1;
		int y = r.nextInt(mazeSize - 2) + 1;
		point.setLocation(x, y);
		return point;
	}

	public static void printMaze(char[][] maze) {

		for (int r = 0; r < maze.length; r++) {
			for (int c = 0; c < maze[r].length; c++) {

				System.out.print(maze[r][c] + " ");
			}
			System.out.println();
		}
	}
}
